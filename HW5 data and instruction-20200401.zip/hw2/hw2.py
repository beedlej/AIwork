#%%
import numpy as np
import heapq
import unittest


map_distances = dict(
    chi=dict(det=283, cle=345, ind=182),
    cle=dict(chi=345, det=169, col=144, pit=134, buf=189),
    ind=dict(chi=182, col=176),
    col=dict(ind=176, cle=144, pit=185),
    det=dict(chi=283, cle=169, buf=256),
    buf=dict(det=256, cle=189, pit=215, syr=150),
    pit=dict(col=185, cle=134, buf=215, phi=305, bal=247),
    syr=dict(buf=150, phi=253, new=254, bos=312),
    bal=dict(phi=101, pit=247),
    phi=dict(pit=305, bal=101, syr=253, new=97),
    new=dict(syr=254, phi=97, bos=215, pro=181),
    pro=dict(bos=50, new=181),
    bos=dict(pro=50, new=215, syr=312, por=107),
    por=dict(bos=107))

sld_providence = dict(
    chi=833,
    cle=531,
    ind=782,
    col=618,
    det=596,
    buf=385,
    pit=458,
    syr=253,
    bal=325,
    phi=236,
    new=157,
    pro=0,
    bos=38,
    por=136)

#%%
def pathcost(path, step_costs):
    '''
    add up the step costs along a path, which is assumed to be a list output from the `path` function above
    '''
    cost = 0
    for s in range(len(path)-1):
        cost += step_costs[path[s]][path[s+1]]
    return cost

def heuristic_sld_providence(state):
    return sld_providence[state]

def uniform_cost(start, goal, state_graph, return_cost, return_nexp):
    queue_list = [(start, 0, start, 0)]
    # (current node, current distance actually traveled, path string, distance + g)
    
    searched_list = []

    while queue_list:   # while there are still items in the queue list
        curr_node = queue_list.pop(0)   # pop off the first item
        
        if curr_node[0] == goal:     # if the current nodes value is equal to the goal
            searched_list.append(curr_node[0])
            retlist = curr_node[2].split(",")
            if return_cost and return_nexp:
                return retlist, curr_node[1], len(searched_list)
            elif return_cost:

                return retlist, curr_node[1]
            elif return_nexp:

                return retlist, len(searched_list)
            else:

                return retlist
        else:
            searched_list.append(curr_node[0])

        for each_conn in state_graph[curr_node[0]]:          # for all connecting values
            distance = state_graph[curr_node[0]][each_conn] + curr_node[1]
            pathstr = curr_node[2] + "," + each_conn
            each_conn = (each_conn, distance, pathstr)
            que_names = [i[0] for i in queue_list]
            
            if each_conn[0] not in searched_list and each_conn[0] not in que_names:     # if not in the searched list already
                queue_list = pq_add2(queue_list, each_conn)
            
            elif each_conn[0] in que_names:
                i = que_names.index(each_conn[0])
                if each_conn[1] < queue_list[i][1]:
                    queue_list[i] = each_conn

                            
    return False



def pq_add2(pq_list, node): # adds node to list based on dist value
    if not pq_list:                  # if the pq list is empty
        return [node]           # return the node as a single item list
    
    if node[1] < pq_list[0][1]:     # if we are inserting right at the beginning, then do it
        retlist = [0] * (len(pq_list) + 1)
        retlist[0] = node
        retlist[1:] = pq_list
        return retlist

    else:
        i = 0
        pqlen = len(pq_list)
        while i < pqlen:    
            curque = pq_list[i]
            if node[1] > curque[1]:     # here we know the node is on at least the same level, so if the value for node 1 is greater move it forward
                i = i + 1
            if node[1] <= curque[1]:
                break    
        if (i == pqlen):
            retlist = [0] * (len(pq_list) + 1)
            for i, each in enumerate(pq_list):
                retlist[i] = each
            retlist[-1] = node
            return retlist

    retlist = [0] * (len(pq_list) + 1)
    curque = pq_list[i]
    retlist[:i+1] = pq_list[:i+1]
    retlist[i] = node
    retlist[i+1:] = pq_list[i:]
    return retlist


def pq_add(pq_list, node): # adds node to list based on dist value
    if not pq_list:                  # if the pq list is empty
        return [node]           # return the node as a single item list
    
    if node[3] < pq_list[0][3]:     # if we are inserting right at the beginning, then do it
        retlist = [0] * (len(pq_list) + 1)
        retlist[0] = node
        retlist[1:] = pq_list
        return retlist

    else:
        i = 0
        pqlen = len(pq_list)
        while i < pqlen:    
            curque = pq_list[i]
            if node[3] > curque[3]:     # here we know the node is on at least the same level, so if the value for node 1 is greater move it forward
                i = i + 1
            if node[3] <= curque[3]:
                break    
        if (i == pqlen):
            retlist = [0] * (len(pq_list) + 1)
            for i, each in enumerate(pq_list):
                retlist[i] = each
            retlist[-1] = node
            return retlist

    retlist = [0] * (len(pq_list) + 1)
    curque = pq_list[i]
    retlist[:i+1] = pq_list[:i+1]
    retlist[i] = node
    retlist[i+1:] = pq_list[i:]
    return retlist

def astar_search(start, goal, state_graph, heuristic, return_cost=False, return_nexp=False):
    queue_list = [(start, 0, start, 0)]
    # (current node, current distance actually traveled, path string, distance + g)
    searched_list = []
    
    while queue_list:   # while there are still items in the queue list
        curr_node = queue_list.pop(0)   # pop off the first item
        #print("queue list", queue_list)
        if curr_node[0] == goal:     # if the current nodes value is equal to the goal
            searched_list.append(curr_node[0])
            retlist = curr_node[2].split(",")
            if return_cost and return_nexp:
                return retlist, curr_node[1], len(searched_list)
            elif return_cost:

                return retlist, curr_node[1]
            elif return_nexp:

                return retlist, len(searched_list)
            else:

                return retlist
        else:
            searched_list.append(curr_node[0])

        #print("searched_list", searched_list)

        for each_conn in state_graph[curr_node[0]]:          # for all connecting values
            distance = state_graph[curr_node[0]][each_conn] + curr_node[1]
            g = heuristic(each_conn)
            pathstr = curr_node[2] + "," + each_conn
            each_conn = (each_conn, distance, pathstr, distance + g)
            que_names = [i[0] for i in queue_list]
            #print("Next Conn", each_conn)

            if each_conn[0] not in searched_list and each_conn[0] not in que_names:     # if not in the searched list already
                queue_list = pq_add(queue_list, each_conn)
            
            elif each_conn[0] in que_names:
                i = que_names.index(each_conn[0])
                if each_conn[3] < queue_list[i][3]:
                    queue_list[i] = each_conn       
    return False   



# %%
path, cost, nexp = astar_search('pit','pro', map_distances, heuristic_sld_providence, return_cost=True, return_nexp=True)
print("Path:",path)
print("Cost:",cost)
print("nexp:", nexp)


path, cost, nexp = uniform_cost('pit','pro', map_distances, return_cost=True, return_nexp=True)
print("Path:",path)
print("Cost:",cost)
print("nexp:", nexp)

# %%
