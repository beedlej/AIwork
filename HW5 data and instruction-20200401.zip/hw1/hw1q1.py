#%%
from collections import deque
from collections import OrderedDict

#['col', 'cle', 'buf', 'syr']
#144,189,150

#['col', 'pit', 'bal', 'syr'], 483)
#185,247,

#(['col', 'pit', 'bal', 'syr'], 483)
#185,247,

graph_distances = dict(
    a = OrderedDict([('b', 1), ('c',4)]),
    b = OrderedDict([('a', 1), ('c',1), ('d', 5)]),
    c = OrderedDict([('b', 1), ('a', 4), ('d',3)]),
    d = OrderedDict([('c', 3), ('b',5), ('g',9), ('e', 8), ('f',3)]),
    e = OrderedDict([('d', 8), ('g', 2)]),
    g = OrderedDict([('e', 2), ('f', 5), ('d', 9)]),
    f = OrderedDict([('d',3), ('g',5)])
)

map_distances = dict(
    chi=OrderedDict([("det",283), ("cle",345), ("ind",182)]),
    cle=OrderedDict([("chi",345), ("det",169), ("col",144), ("pit",134), ("buf",189)]),
    ind=OrderedDict([("chi",182), ("col",176)]),
    col=OrderedDict([("ind",176), ("cle",144), ("pit",185)]),
    det=OrderedDict([("chi",283), ("cle",169), ("buf",256)]),
    buf=OrderedDict([("det",256), ("cle",189), ("pit",215), ("syr",150)]),
    pit=OrderedDict([("col",185), ("cle",134), ("buf",215), ("phi",305), ("bal",247)]),
    syr=OrderedDict([("buf",150), ("phi",253), ("new",254), ("bos",312)]),
    bal=OrderedDict([("phi",101), ("pit",247)]),
    phi=OrderedDict([("pit",305), ("bal",101), ("syr",253), ("new",97)]),
    new=OrderedDict([("syr",254), ("phi",97), ("bos",215), ("pro",181)]),
    pro=OrderedDict([("bos",50), ("new",181)]),
    bos=OrderedDict([("pro",50), ("new",215), ("syr",312), ("por",107)]),
    por=OrderedDict([("bos",107)]))

map_times = dict(
    chi=dict(det=280, cle=345, ind=200),
    cle=dict(chi=345, det=170, col=155, pit=145, buf=185),
    ind=dict(chi=200, col=175),
    col=dict(ind=175, cle=155, pit=185),
    det=dict(chi=280, cle=170, buf=270),
    buf=dict(det=270, cle=185, pit=215, syr=145),
    pit=dict(col=185, cle=145, buf=215, phi=305, bal=255),
    syr=dict(buf=145, phi=245, new=260, bos=290),
    bal=dict(phi=145, pit=255),
    phi=dict(pit=305, bal=145, syr=245, new=150),
    new=dict(syr=260, phi=150, bos=270, pro=260),
    pro=dict(bos=90, new=260),
    bos=dict(pro=90, new=270, syr=290, por=120),
    por=dict(bos=120))
#%%
# Solution:
def pathcost(path, step_costs):
    '''
    add up the step costs along a path, which is assumed to be a list output from the `path` function above
    '''
    cost = 0
    for s in range(len(path)-1):
        cost += step_costs[path[s]][path[s+1]]
    return cost

#%%
def depth_first(start, goal, graph, cost):
    queue_list = [start]
    searched_list = []
    path_list = [start]
    lvl_dict = {start : 0}
    states_visited = 0
    traveled_distance = 0

    if not start or not goal or not graph:  # without any of these we cant search
        #print("Function input incorrect")
        return False

    elif start == goal:     # if the current nodes value is equal to the goal
        return True

    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop()   # pop off the LAST item
            searched_list.append(curr_node)
            states_visited = states_visited + 1
            #print("Current node is:", curr_node)
            #print("List of already searched nodes:", searched_list)
            #print("Queue", queue_list)
            #print("lvldict", lvl_dict)
            #print("current tree level", lvl_dict[curr_node])
            #print("Path list:", path_list)

            if path_list[-1] != curr_node:  # if the last item in path list is not equal to current node
                #print("Comparing path_list[-1] lvl: ", lvl_dict[path_list[-1]], "To curr_node lvl: ", lvl_dict[curr_node])
                while lvl_dict[path_list[-1]] >= lvl_dict[curr_node]:  # if the current node is equal to the last node
                    #print("Removing last element from path_list: ", path_list[-1])
                    path_list.pop() # take off the last node on the path list, because it was not the correct way
                    #print("Adding current element to: ", curr_node)
                path_list.append(curr_node) # then add the current node


            for each_conn in graph[curr_node]:          # for all connecting values
                if each_conn not in searched_list and each_conn not in queue_list:     # if not in the searched list already
                    
                    if each_conn == goal:     # if the current nodes value is equal to the goal
                        #print("Found it!", each_conn, goal)
                        #print("lvldict", lvl_dict)
                        #print("current tree level", lvl_dict[curr_node], path_list)
                        #traveled_distance = traveled_distance + graph[curr_node][each_conn]
                        if cost:
                            path_list.append(each_conn)
                            return path_list, pathcost(path_list, graph)
                        else:
                            return path_list
                    #print("adding : ", each_conn, " to que with value", graph[curr_node][each_conn])
                    lvl_dict[each_conn] = lvl_dict[curr_node] + 1
                    # add to lvl dict the horizon node, as well as its level which is 
                    # 1 level above the curr node

                    queue_list.append(each_conn)        # go ahead and append to the queue list

        return False, states_visited
#%%
depth_first('a','g', graph_distances, True)
#%%
def breadth_first(start, goal, graph, cost):
    queue_list = [(start, 0 , start)]
    searched_list = []
    lvl_dict = {start : 0}
    states_visited = 0

    if not start or not goal or not graph:  # without any of these we cant search
        #print("Function input incorrect")
        return False

    elif start == goal:     # if the current nodes value is equal to the goal
        return True

    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop(0)   # pop off the first item

            searched_list.append(curr_node[0])

            states_visited = states_visited + 1

            que_names = [i[0] for i in queue_list]

            for each_conn in graph[curr_node[0]]:          # for all connecting values
                if each_conn not in searched_list and each_conn not in que_names:     # if not in the searched list already
                    
                    distance = graph[curr_node[0]][each_conn] + curr_node[1]

                    pathstr = curr_node[2] + "," + each_conn
                    
                    each_conn = (each_conn, distance, pathstr)

                    if each_conn[0] == goal:     # if the current nodes value is equal to the goal
                        retlist = pathstr.split(",")
                        if cost:
                            return retlist, distance
                        else:
                            return retlist
                    #print("adding : ", each_conn, " to que with value", graph[curr_node][each_conn])

                    # add to lvl dict the horizon node, as well as its level which is 
                    # 1 level above the curr node

                    queue_list.append(each_conn)        # go ahead and append to the queue list

        return False, states_visited

 #add your code here

#%%
breadth_first('a','g', graph_distances, True)
#path, cost = breadth_first('chi','pit',map_distances,True)
#print(path)
#print(cost)


# %%
def pq_add(pq_list, node): # adds node to list based on dist value
    if not pq_list:                  # if the pq list is empty
        return [node]           # return the node as a single item list
    
    if node[1] < pq_list[0][1]:     # if we are inserting right at the beginning, then do it
        retlist = [0] * (len(pq_list) + 1)
        retlist[0] = node
        retlist[1:] = pq_list
        return retlist

    else:
        i = 0
        pqlen = len(pq_list)
        while i < pqlen:    
            curque = pq_list[i]
            if node[1] > curque[1]:     # here we know the node is on at least the same level, so if the value for node 1 is greater move it forward
                i = i + 1
            if node[1] <= curque[1]:
                break    
        if (i == pqlen):
            retlist = [0] * (len(pq_list) + 1)
            for i, each in enumerate(pq_list):
                retlist[i] = each
            retlist[-1] = node
            return retlist

    retlist = [0] * (len(pq_list) + 1)
    curque = pq_list[i]
    retlist[:i+1] = pq_list[:i+1]
    retlist[i] = node
    retlist[i+1:] = pq_list[i:]
    return retlist


#%%
pq = []
pq = pq_add(pq, ("toy", 150))
pq = pq_add(pq, ("tad", 100))
pq = pq_add(pq, ("tob", 160))
pq = pq_add(pq, ("rat", 90))
pq = pq_add(pq, ("rat", 100))
pq = pq_add(pq, ("toy", 0))
pq = pq_add(pq, ("tad", 3))
pq = pq_add(pq, ("tad", 2))
pq = pq_add(pq, ("tad", 4))
pq = pq_add(pq, ("tob", 199))
pq = pq_add(pq, ("rat", 900))
pq = pq_add(pq, ("rat", 13))
print(pq)        
#%%


# Solution:
#%%

def uniform_cost(start, goal, graph, cost=False):
    queue_list = [(start, 0, start)]   
    searched_list = []
    path_list = [(start, 0)]
    lvl_dict = {start : 0}
    states_visited = 0

    if not start or not goal or not graph:  # without any of these we cant search
        #print("Function input incorrect")
        return False

    elif start == goal:     # if the current nodes value is equal to the goal
        return True

    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop(0)   # pop off the first item
            if curr_node[0] == goal:     # if the current nodes value is equal to the goal
                retlist = curr_node[2].split(",")
                if cost:
                    return retlist, curr_node[1]
                else:
                    return retlist
            else:
                searched_list.append(curr_node[0])


            for each_conn in graph[curr_node[0]]:          # for all connecting values
                
                distance = graph[curr_node[0]][each_conn] + curr_node[1]
                pathstr = curr_node[2] + "," + each_conn
                each_conn = (each_conn, distance, pathstr)
                que_names = [i[0] for i in queue_list]
                

                if each_conn[0] not in searched_list and each_conn[0] not in que_names:     # if not in the searched list already
                    lvl_dict[each_conn[0]] = lvl_dict[curr_node[0]] + 1

                    queue_list = pq_add(queue_list, each_conn)
                
                
                elif each_conn[0] in que_names:
                    i = que_names.index(each_conn[0])
                    if each_conn[1] < queue_list[i][1]:
                        queue_list[i] = each_conn
                            

        return False

# %%
print(uniform_cost('a','g', graph_distances, True))

# %%

['col', 'cle', 'buf', 'syr']
483

# %%
import numpy as np

def maze_to_graph(maze):
    ''' takes in a maze as a numpy array, converts to a graph '''
    retdict = {}
    ret = np.asmatrix(maze)
    cols = len(maze[0]) -1
    rows = len(maze) -1

    for y in range(0,rows + 1):
        for x in range(0,cols + 1):
            dictstring = []
            try:
                if maze[y+1][x] == 0:
                    dictstring.append(((x,y + 1) , "N"))
            except:
                pass 

            try:
                if maze[y-1][x] == 0:
                    dictstring.append(((x,y - 1) , "S"))
            except:
                pass

            try:
                if maze[y][x + 1] == 0:
                    dictstring.append(((x+1, y), "E"))
            except:
                pass

            try:
                if maze[y][x-1] == 0:
                    dictstring.append(((x-1,y) , "W"))
            except:
                pass
            if dictstring:
                retdict[x,y] = dict(dictstring)

    return retdict            
    


#%%

#testmaze = np.array([[1, 1, 1, 1, 1],[1, 0, 0, 0, 1],[1, 0, 0, 0, 1],[1, 1, 1, 1, 1]])
#testgraph = maze_to_graph(testmaze)

testmaze = np.ones((4,4))
testmaze[1,1] = 0
testmaze[2,1] = 0
testmaze[2,2] = 0

print(testmaze)

testgraph = maze_to_graph(testmaze)


print(testgraph[(1,1)])
print(testgraph[(1,2)])
print(testgraph[(2,2)])
# %%
# version with string output
def breadth_first(start, goal, graph):
    queue_list = [(start, start)]
    searched_list = []
    if not start or not goal or not graph:  # without any of these we cant search
        return False
    elif start == goal:     # if the current nodes value is equal to the goal
        return True
    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop(0)   # pop off the first item
            searched_list.append(curr_node[0])
            que_names = [i[0] for i in queue_list]
            for each_conn in graph[curr_node[0]]:          # for all connecting values
                if each_conn not in searched_list and each_conn not in que_names:     # if not in the searched list already
                    pathstr = curr_node[1]
                    pathstr.append(each_conn)
                    if each_conn == goal:     # if the current nodes value is equal to the goal
                        return pathstr
                    else:
                        each_conn = (each_conn, pathstr)
                    queue_list.append(each_conn)        # go ahead and append to the queue list

        return False

#%%
import numpy as np
maze = np.array([[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                 [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                 [1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1],
                 [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                 [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1],
                 [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1],
                 [1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1],
                 [1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1],
                 [1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1],
                 [1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1],
                 [1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1],
                 [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]])

def breadth_first(start, goal, graph):
    queue_list = [(start, [start])]
    searched_list = []
    if not start or not goal or not graph:  # without any of these we cant search
        return False
    elif start == goal:     # if the current nodes value is equal to the goal
        return True
    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop(0)   # pop off the first item
            searched_list.append(curr_node[0])
            que_names = [i[0] for i in queue_list]
            for each_conn in graph[curr_node[0]]:          # for all connecting values
                if each_conn not in searched_list and each_conn not in que_names:     # if not in the searched list already
                    pathstr = curr_node[1]
                    pathstr.append(each_conn)
                    if each_conn == goal:     # if the current nodes value is equal to the goal
                        return pathstr
                    else:
                        each_conn = (each_conn, pathstr)
                        pathstr = curr_node[1]
                        queue_list.append(each_conn)        # go ahead and append to the queue list
        return False


def breadth_first1(start, goal, graph):
    queue_list = [(start, (start,))]
    searched_list = []


    if not start or not goal or not graph:  # without any of these we cant search
        #print("Function input incorrect")
        return False

    elif start == goal:     # if the current nodes value is equal to the goal
        return True

    else:
        while queue_list:   # while there are still items in the queue list
            curr_node = queue_list.pop(0)   # pop off the first item
            searched_list.append(curr_node[0])
            que_names = [i[0] for i in queue_list]

            for each_conn in graph[curr_node[0]]:          # for all connecting values
                if each_conn not in searched_list and each_conn not in que_names:     # if not in the searched list already
                    
                    pathstr = curr_node[1] + (each_conn,)
                    each_conn = (each_conn, pathstr)

                    if each_conn[0] == goal:     # if the current nodes value is equal to the goal
                        
                        return list(pathstr)
                    #print("adding : ", each_conn, " to que with value", graph[curr_node][each_conn])

                    # add to lvl dict the horizon node, as well as its level which is 
                    # 1 level above the curr node

                    queue_list.append(each_conn)        # go ahead and append to the queue list

        return False, states_visited

def maze_to_graph(maze):
    ''' takes in a maze as a numpy array, converts to a graph '''
    retdict = {}
    ret = np.asmatrix(maze)
    cols = len(maze[0]) -1
    rows = len(maze) -1
    print
    for y in range(0,rows + 1):
        for x in range(0,cols + 1):
            dictstring = []
            try:
                if maze[y+1][x] == 0:
                    dictstring.append(((x,y + 1) , "N"))
            except:
                pass 
            try:
                if maze[y][x + 1] == 0:
                    dictstring.append(((x+1, y), "E"))
            except:
                pass
            try:
                if maze[y-1][x] == 0:
                    dictstring.append(((x,y - 1) , "S"))
            except:
                pass
            try:
                if maze[y][x-1] == 0:
                    dictstring.append(((x-1,y) , "W"))
            except:
                pass
            
            if dictstring:
                retdict[x,y] = dict(dictstring)

    return retdict            

#%%
g_maze = maze_to_graph(maze)

maze_sol_bfs = breadth_first1((1,1), (10,10), g_maze)
print('Breadth-first search yields: {} ({} steps)'.format(maze_sol_bfs, len(maze_sol_bfs)))

# %%

