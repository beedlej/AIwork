#%%
import keras
from keras.models import Sequential # class inside keras.models module allowing us to build an object
import numpy as np
import pandas as pd
from keras.layers import Dense, Activation, Dropout
import statsmodels.api as sm
import statsmodels.formula.api as smf
#%%
X2 = pd.read_csv("train.csv")
x_res1 = X2['STENT'].to_numpy().reshape(len(X2),1) # pull out the training y

good_candidates = []
for col in X2.columns:
    form = 'ffr~'+col # formula for the regression
    model_trn = smf.ols(form, data=X2).fit()
    mod_r2 = model_trn.rsquared
    if mod_r2 > .03 and col not in ['STENT', 'PID', 'ffr']:
        good_candidates.append(col)
print(len(good_candidates))
print("MODEL 1")
del X2['STENT'] # remove stent and ffr from the train data
del X2['ffr']
del X2['PID']

model1 = sm.OLS(x_res1, X2).fit()
print(model1.summary())


new_x = pd.DataFrame()
for good_col in good_candidates:
    new_x.insert(0, column = good_col, value = X2[good_col])


print("MODEL 2")
model2 = sm.OLS(x_res1, new_x).fit()
print(model2.summary())
#%%
def main():

    #input_dim_ = X.shape[1] # number of categories, will be input to first layer
    input_dim_ = len(good_candidates)

    model = Sequential()
    rms = keras.optimizers.RMSprop(learning_rate=0.00001, rho=0.9) 
    model.add(Dense(32, activation='relu', input_dim=input_dim_)) # input layer is a relu
    model.add(Dropout(0.5)) # dropout layer to prevent overfitting
    model.add(Dense(64, activation='relu')) # additional relu layer
    model.add(Dropout(0.5)) # dropout
    model.add(Dense(32, activation='relu')) # additional relu layer
    model.add(Dropout(0.5)) # dropout
    model.add(Dense(64, activation='relu')) # additional relu layer
    model.add(Dropout(0.5)) # dropout
    model.add(Dense(32, activation='relu')) # additional relu layer
    model.add(Dropout(0.5)) # dropout

    model.add(Dense(1, activation='sigmoid')) #
    model.compile(optimizer=rms,loss="binary_crossentropy",metrics=['accuracy'])

    #model.fit(X_nump,x_res1,epochs=1000, batch_size=32, use_multiprocessing=True, verbose=1)
    model.fit(new_x,x_res1,epochs=1000, batch_size=32, use_multiprocessing=True, verbose=1)
    y = pd.read_csv("test.csv")
    pid_list = y['PID'].values
    del y['PID']
    y_ = y.to_numpy()
    new_y = pd.DataFrame()
    
    for good_col in good_candidates:
        new_y.insert(0, column = good_col, value = y[good_col])
    ret = model.predict(new_y).flatten()
    
    stent_probs = pd.DataFrame(ret).values.flatten()
    pd_ret = pd.DataFrame({'PID': pid_list, 'STENT': ret})
    pd_ret.set_index('PID', inplace = True)
    pd_ret.to_csv("output.csv")

main()


# %%
