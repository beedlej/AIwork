#%%
import numpy as np
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
#%%
#sample = pd.read_csv("sample_submission.csv")

X = pd.read_csv("train.csv")
x_res = X['STENT']
del X['STENT']
del X['ffr']

#%%
nbrs = KNeighborsClassifier(n_neighbors=10).fit(X,x_res)


# %%
y = pd.read_csv("test.csv")

# %%
r = pd.DataFrame(nbrs.predict_proba(y))
pid_list = 
stent_probs = pd.DataFrame(r)
# %%
pd_ret = pd.DataFrame({'PID': y['PID'].values, 'STENT': r})

# %%
pr

# %%


# %%
f

# %%
