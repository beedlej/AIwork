## Background
<p>Heart disease is the most leading cause of death in the United States. According to CDC  <sup>[1]</sup>, about 650,000 people die from heart disease each year in the US. Coronary artery disease is the most common type of heart disease, and it causes heart attacks which over 800,000 people in the US have each year. Coronary artery disease occurs due to blockages (plaque) developed inside the coronary arteries (blood vessels that feed heart muscles). Cardiologists use various imaging techniques and invasive blood pressure measurements to examine and monitor severity of such blockage. Intravascular ultrasound (IVUS) and Fractional flow reserve (FFR) are commonly used to examine the position and severity of plaque deposition. </p>
<p> While IVUS is used to find out where the blockage is, and to examine morphology of the lesions, FFR measures the blood pressure directly inside the coronary artery. It is defined as a ratio of distal pressure to the proximal pressure in the coronary artery and is a indicator of how severe the blockage is at the lesion. If the FFR value is smaller than 0.8, it is advised to perform a STENT placement surgery.</p>
<p>The provided data in this competition is a real data gathered in the Asan Medical Center in Korea from about 1500 coronary artery disease patients. The patients' sensitive data were removed, the ultrasound images were processed using a deep learning image segmentation algorithm, and more than 100 features were extracted from the processed images (Please see the paper [2] for more details).</p>
<p>Your task is to build a machine learning model(s) to predict whether the patient needs a STENT placement surgery or not.</p>  

## Data Description
The train data has 114 columns- 1 patient ID (PID) column, 111 feature columns, and 2 target columns. The `ffr` column is the actual measured value, and `STENT` is a binarized version of `ffr` (STENT = 1 when ffr < 0.8). The test data has 112 columns- 1 patient ID (PID) column and 111 features. The test data does not have the `ffr` and `STENT` because you will be predicting `STENT`.

## Evaluation Metric and Kaggle Submission Guide
You may train using whichever performance metric you like, however the Kaggle competition will use binary cross entropy (also called log loss), which takes the probability as input and can give more insights about how accurate and confident your classifier is than what simple accuracy metric can offer. That means, you should submit the prediction probability output instead of binarized labels.  

For Kaggle use only: Use the sample submission format when you submit to kaggle. The STENT column is your prediction probability.

## Data Use Policy
<p>The data is private and limited to educational use. Please do not distribute the data or use for other purpose than this class's in-class Kaggle competition</p>
<h2>References</h2>

[1] [CDC Heart Disease Facts](https://www.cdc.gov/heartdisease/facts.htm)       
[2] [Prediction of FFR from IVUS Images Using Machine Learning](https://link.springer.com/chapter/10.1007/978-3-030-01364-6_9)   
