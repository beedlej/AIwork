# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util
import time

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()
        #print("Our legal moves here are ", legalMoves)
        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
      
        # Useful information you can extract from a GameState (pacman.py)
        ghostlist = currentGameState.getGhostPositions()

        #print("Ghostlist", ghostlist)
        #print("Current game state \n", currentGameState)
        #print("Heres the action!", action)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        #print("Sucessor state \n", successorGameState)
        newPos = successorGameState.getPacmanPosition()
        #print("after moving from", currentGameState.getPacmanPosition(), "in direction", action, "pacman will be at coordinates", newPos)
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        
        #newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
        #print(newPos)
        #print(newFood)
        #print(newGhostStates)
        "*** YOUR CODE HERE ***"

        manhattdg = manhattanDistance(ghostlist[0], newPos)
        
        # so we are really returning a number to getAction which is passing all the legal moves at a certain
        # state. Right now it only returns the score, but this doesnt take into account if we are colliding
        # with a ghost or not.
        succ_score = successorGameState.getScore()
        #print("FOOOD \n" + str(newFood))
        #print(succ_score)
        if manhattdg <= 1.5:
          # being close to a ghost is bad
          succ_score -= 20
        # check out the new position, if there are pellets around the new position then it is superior to old
        x = newPos[0]
        y = newPos[1]
        #print(newFood[x][y])
        adder2= 1
        for num in range(1,3):
          try:
            if newFood[x+num][y] == True:
              #print("adding 3 to succscore")
              succ_score += adder2 
              break
          except:
            pass

          try:
            if newFood[x][y-num] == True:
              #print("adding 3 to succscore")
              succ_score += adder2 
              break
          except:
            pass
          
          try:
            if newFood[x-num][y] == True:
              #print("adding 3 to succscore")
              succ_score += adder2 
              break
          except:
            pass
          
          try:
            if newFood[x][y+num] == True:
              #print("adding 3 to succscore")
              succ_score += adder2 
          except:
            pass

        return succ_score 

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
      
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
 
        moves = []

        #print("Starting at: ", gameState)
        def minimax(depth, currentState, minormax):
          #print("Current depth is: ", depth)
          numagents = currentState.getNumAgents()
          op_move = ""
          if ( currentState.isWin() or currentState.isLose()): 
            #print("reached terminal state")
            f = self.evaluationFunction(currentState)
            return f
            
          if (minormax == 0): # if we are pacman / max agent
            #print("Pacmans move")

            if depth == self.depth:
              return self.evaluationFunction(currentState)

            value = float("-inf")
            legal_moves = currentState.getLegalActions(0)
            #node_list = []

            for move in legal_moves:
              node1 = currentState.generateSuccessor(minormax, move) # generate future node
              leaf_val = minimax(depth,node1,1) # passes to 1 which is first ghost
              if leaf_val > value:
                op_move = move
                value = leaf_val

            moves.append(op_move)
            
            return value

          # otherwise, ghost so min agent
          else:
            #print("other agent move")
            #print("Checking ghosts", minormax, numagents)
            value = float("inf")
            legal_moves = currentState.getLegalActions(minormax)  #gen legal moves
            
            if minormax < numagents-1 : # we are still in ghost
              for move in legal_moves:  
                node1 = currentState.generateSuccessor(minormax, move)
                leaf_val = minimax(depth, node1, minormax + 1)
                if leaf_val < value:
                  value = leaf_val

            else: # we are on last ghost, so getting ready to pass to pacman   
              for move in legal_moves:  
                node1 = currentState.generateSuccessor(minormax, move)
                leaf_val = minimax(depth + 1, node1, 0)
                if leaf_val < value:
                  value = leaf_val

            return value

        f = minimax(0 , gameState, 0)

        
        return moves[-1]


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        
        def alphabetamax(depth, currentState, alpha, beta):
          
  
          if (self.depth == depth or currentState.isWin() or currentState.isLose()): 
            return self.evaluationFunction(currentState)
            
          
          value = float("-inf")
          temp_val = value
          legal_moves = currentState.getLegalActions(0)
          op_move = ""

          for move in legal_moves:
            node1 = currentState.generateSuccessor(0, move) # generate future node
            temp_val = alphabetamin(depth ,node1 ,1 ,alpha, beta) # passes to 1 which is first ghost
            if temp_val > value:
              op_move = move
              value = temp_val
            alpha = max(alpha, value)
            print("PacmansStateGenned", move, temp_val)
            if value > beta:
              return value
              # once the recursion calls from above come back, just return the first move
          if depth == 0:
            print("Pacman Move", op_move, value)
            return op_move
            # otherwise, further down the tree so return value
          else:
            return value

            #moves.append(op_move)
            #return value

 
        def alphabetamin(depth, currentState, minormax, alpha, beta):
          
          if ( self.depth == depth or currentState.isWin() or currentState.isLose()): 
            return currentState.getScore()

          value = float("inf")
          leaf_val = value
          legal_moves = currentState.getLegalActions(minormax)  #gen legal moves
          
          if minormax < currentState.getNumAgents() -1 : # we are still in ghost
            for move in legal_moves:  
              
              node1 = currentState.generateSuccessor(minormax, move)
              
              leaf_val = alphabetamin(depth, node1, minormax + 1, alpha, beta)
              print("Minimizer", move, leaf_val)
      
              if leaf_val < value:
                value = leaf_val
              beta = min(beta,value)
              if value < alpha:
                return value
                
          else: # we are on last ghost, so getting ready to pass to pacman   
            
            for move in legal_moves:  
              node1 = currentState.generateSuccessor(minormax, move)

              if depth == self.depth - 1:
                leaf_val = self.evaluationFunction(node1)
              else:
                leaf_val = alphabetamax(depth + 1, node1, alpha, beta)

              if leaf_val < value:
                value = leaf_val
              beta = min(beta,value)
              print("minimizer last move", move, leaf_val)
              if value < alpha:
                return value

          return value
        
        alpha = float("-inf")
        beta = float("inf")

        
        #print("should be right after breaking out")
        return alphabetamax(0 , gameState, alpha, beta)

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        def values(currentState,agent,depth):
          if (depth == self.depth or currentState.isWin() or currentState.isLose()): 
            f = self.evaluationFunction(currentState)
            return f

          elif not agent: # max node
            return maxV(currentState,depth)
          else: # expectimax node
            return expV(currentState,agent,depth)


        def maxV(currentState,depth):
          value = float("-inf")
          temp_val = value
          legal_moves = currentState.getLegalActions(0)

          op_move = ""
          for move in legal_moves:
            node1 = currentState.generateSuccessor(0, move) # generate future node
            temp_val = values(node1 ,1 ,depth) # passes to 1 which is first ghost
            if temp_val > value:
              op_move = move
              value = temp_val
          if depth == 0: # final recursive call will be the optimal move
            return op_move
          else: # otherwise returning max value
            return value

        def expV(currentState,agent,depth):
          value = 0
          leaf_val = value
          legal_moves = currentState.getLegalActions(agent)  #gen legal moves
          
          if agent < currentState.getNumAgents() -1 : # we are still in ghost
            for move in legal_moves:  
              node1 = currentState.generateSuccessor(agent, move)
              leaf_val = values(node1, agent + 1, depth)
              value += leaf_val
                
          else: # we are on last ghost, so getting ready to pass to pacman   
            
            for move in legal_moves:  
              node1 = currentState.generateSuccessor(agent, move)
              leaf_val = values(node1, 0, depth + 1)
              value += leaf_val
              
            # take expected value, so sum of values over length of legal moves b/c uniform
          return float(value/(len(legal_moves)))

        # return values with current state, pacman starting, depth at 0, nodetype 0
        return values(gameState, 0, 0)

def betterEvaluationFunction(currentState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    newPos = currentState.getPacmanPosition() # get pacmans position coordinates
    food_grid = currentState.getFood() #Returns a Grid of boolean food indicator variables. Grids can be accessed via list notation, so to check if there is food at (x,y), just call if currentFood[x][y] == True: ...
    
    num_food = currentState.getNumFood()

    totdist = 0
    
    for y,row in enumerate(food_grid):  # for all rows, or y coords
      for x,food_bool in enumerate(row): # for all food boolean items, or x values
        #print(column, x)
        if food_bool: # if there is food here
          totdist += manhattanDistance(newPos,(x,y))  # add the manhattan distance between the food and pacman
        
    #food_dist_ratio = totdist/num_food  # calculates ratio between 

    totdist_food = totdist

    ghost_pos = currentState.getGhostPositions()

    totdist = 0

    for coord in ghost_pos:
      totdist += manhattanDistance(newPos,coord)

    totdist_ghost = totdist 

    curr_score = currentState.getScore()

    # a state where pacman is closer to more dots is better closetodots

    # a state with less dots is better dotseaten

    # more food is bad so negative food
    if totdist_food == 0:
      totdist_food = 1
      # take current score, minus food * inverse of total food distance, minus total ghost distance
    equat = curr_score - (num_food * 1/totdist_food) - totdist_ghost
    #print(equat)

    return equat

# Abbreviation
better = betterEvaluationFunction

