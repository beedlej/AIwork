moves = []

        #print("Starting at: ", gameState)
        
        



def max_v(depth, currentState, alpha, beta):
        legal_moves = currentState.getLegalActions(0)
        v = float("-inf")
        states = []
        for move in legal_moves:
          states.append((currentState.generateSuccessor(0,move),move))

        for successor_state of states:
          v, move = max(v , min_v(depth, successor_state[0], alpha, beta, 1))
          if v > beta:
            return v
          alpha = max(alpha,v)
        return v
    
      def min_v(depth,currentState,alpha,beta,ghostno):
        legal_moves = currentState.getLegalActions(ghostno)
        v = float("inf")
        states = []
      
        if (ghostno == currentState.getNumAgents() - 1): # for last ghost
          for move in legal_moves:
            states.append(currentState.generateSuccessor(ghostno,move))

          for successor_state of states:
            v = max( v, max_v(depth + 1, successor_state[0], alpha, beta))
            if v < alpha:
              return v
            beta = max(beta,v)
          return v

        else:
          for move in legal_moves:
            states.append((currentState.generateSuccessor(0,move),move))

          for successor_state of states:
            v, move = max( v, min_v(depth + 1, successor_state[0], alpha, beta, ghostno + 1))
            if v < alpha:
              return v
            beta = max(beta,v)
          return v




def alphabetamax(depth, currentState, alpha, beta):
 
          if (currentState.isWin() or currentState.isLose()): 
            return currentState.getScore()
            
          
          value = float("-inf")
          temp_val = value
          legal_moves = currentState.getLegalActions(0)
          op_move = ""

          for move in legal_moves:
            node1 = currentState.generateSuccessor(0, move) # generate future node
            temp_val = alphabetamin(depth ,node1 ,1 ,alpha, beta) # passes to 1 which is first ghost
            if temp_val > value:
              op_move = move
              value = temp_val
            alpha = max(alpha, value)
              
            if value > beta:
              return value
          if depth == 0:
            return op_move
          else:
            return value

            #moves.append(op_move)
            #return value

 
        def alphabetamin(depth, currentState, minormax, alpha, beta):
          
          if (currentState.isWin() or currentState.isLose()): 
            return currentState.getScore()

          value = float("inf")
          leaf_val = value
          legal_moves = currentState.getLegalActions(minormax)  #gen legal moves
          
          if minormax < currentState.getNumAgents() -1 : # we are still in ghost
            for move in legal_moves:  
              node1 = currentState.generateSuccessor(minormax, move)
              
              leaf_val = alphabetamin(depth, node1, minormax + 1, alpha, beta)
              if leaf_val < value:
                value = leaf_val
              beta = min(beta,value)
              if value < alpha:
                return value
                


          else: # we are on last ghost, so getting ready to pass to pacman   
            
            for move in legal_moves:  
              node1 = currentState.generateSuccessor(minormax, move)

              if depth == self.depth - 1:
                leaf_val = self.evaluationFunction(node1)
              else:
                leaf_val = alphabetamax(depth + 1, node1, alpha, beta)

              if leaf_val < value:
                value = leaf_val
              beta = min(beta,value)

              if value < alpha:
                return value

          return value
        
        alpha = float("-inf")
        beta = float("inf")

        
        #print("should be right after breaking out")
        return alphabetamax(0 , gameState, alpha, beta)