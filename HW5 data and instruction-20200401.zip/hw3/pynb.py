#%%
q5a = (.5 * 3.153) + .5*(8.0+(.5*(2.73)))
#%%
print(q5a) 

# %%
def pdqsa(alpha,discount,qsa,qsaprime,saw):
    

# %%
qsa = .5 * 2.133
dsctqsap = 1.501 * .5
num3 = dsctqsap * .5

q5b = qsa + num3
# %%
print(qsa)
print(q5b)
#print(dsctqsap)
print(num3)
# %%
