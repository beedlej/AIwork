#%%
from math import random

#%%
dice_prob = 1/6

#%%
sum1 = 0
for num in range(1,7):
    r = 1/6 * num
    sum1 += r
    prunt(sum1)